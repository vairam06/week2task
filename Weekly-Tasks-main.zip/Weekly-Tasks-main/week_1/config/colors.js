export default color = {
  red: "#fc5c65",
  green: "#4ECDC4",
};
